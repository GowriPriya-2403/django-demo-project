# while(True):
#     try:
#         n1=int(input("Enter number"))
#         n2=int(input("Enter number"))
#         r=n1/n2
#     except:
#         print("Zero Division Error")
#     else:
#         print(r)
#         exit()
def f():
    try:
        n1=int(input("Enter number"))
        n2=int(input("Enter number"))
        r=n1/n2
    except:
        print("Error")
        f()

    else:
        print(r)
f()
