try:
    x=int(input("enter"))
    y=int(input("enter"))
    print(x+y)
except ValueError as s:
    print(s,type(s))
    #print("Value error")
# x=int(input("enter"))
# y=int(input("enter"))
# print(x+y)
