try:
        n1=int(input("Enter number"))
        n2=int(input("Enter number"))
        r=n1/n2
        #print(R)
except ZeroDivisionError as e:
        print(e,type(e))
except ValueError as e:
        print(e,type(e))

except Exception as e:
        print(e,type(e))
finally:
       print(r)
       print("hello")