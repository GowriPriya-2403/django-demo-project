# try:
#     x=int(input("enter no"))
#     y=int(input("enter no"))
#     z=x/y
#     print(z)
# except:
#     print("Zero Divison Error")
# finally:
#     print("hello")
#Using Function Recursion
def add(a,b):
    print(a+b)

def sub(a,b):
    print(a-b)
def f():
    try:

        a=int(input())

        b=int(input())

        add(a,b)
        sub(a,b)
    except Exception as e:
        print(type(e),e)
        f()

    else:
        pass
f()
# #Using While loop
#
# def add(a,b):
#     print(a+b)
#
# def sub(a,b):
#     print(a-b)
# while(1):
#     try:
#         a=int(input())
#         b=int(input())
#         add(a,b)
#         sub(a,b)
#     except:
#         pass
#
#     else:
#         break



