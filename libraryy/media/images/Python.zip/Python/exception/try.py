try:
    x=["red","green"]
    if "blue" not in x:
        raise ValueError()
except:
    print("hello")