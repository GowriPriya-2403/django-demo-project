import math
try:
    x=open("f.txt","r")
    print(x.read())
except:
    print("File does not exist")
else:
    x.close()
