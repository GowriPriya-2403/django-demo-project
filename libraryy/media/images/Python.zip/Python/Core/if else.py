#Maximum of two numbers
a=int(input("Enter the first number"))
b=int(input("Enter the second number"))
if(a>b):
    print("First number is biggest")
else:
    print("Second Number is Biggest")
#Even or odd
a=int(input("Enter number"))
if(a%2==0):
    print("Even number")
else:
    print("Odd number")
#Divisible by 2 and 5
a=int(input("Enter number"))
if(a%2==0 and a%5==0):
    print("Number is divisible by 2 and 5")
else:
    print("Number is not Divisible by 2 and 5")
#Element present in a list
l=[34,76,89,32,11]
a=int(input("Enter number"))
if (a in l):
    print("Number is present in the given list")
else:
    print("Not Present")