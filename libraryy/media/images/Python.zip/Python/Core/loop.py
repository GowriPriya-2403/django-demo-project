# #range(1,11)
# for i in range(1,11):
#     print(i)
# # i=1     1
# # i=2     2
# # --
# # i=10    10
#
# #range(10,0,-1)
# for i in range(10,0,-1):
#     print(i)
# # i=10  10
# # i=9    9
# # --
# # i=1    1
#
# # range(1,10,2)
# # for i in range(1,10,2):
# #     print(i)
# # # i=1     1
# # # i=3      3
# # # i=5      5
# # # i=7       7
# # # i=9       9
# #
#
#
# s="hello"
# for i in s:
#     print(i,end=" ")
# print()
# for i in range(0,len(s)):
#     print(s[i],end=" ")
# # i=0    s[0]-->'h'
# # i=1    s[1]-->'e'
# #
# # i=4    s[4]-->o
# print()

# l=[1,2,3,4]
# for i in l:
#     print(i,end=" ")
# print()
# for i in range(0,len(l)):
#     print(l[i],end=" ")
# print()
# for i in range(len(l)-1,-1,-1):
#     print(l[i],end=" ")
#Reverse of a number
# s="hello"
# for i in range(len(s)-1,-1,-1):
#     print(s[i],end=" ")
# n=234
# s=str(n)
# for i in range(len(s)-1,-1,-1):
#     print(s[i],end="")

str="PYTHON"
"P"
"PY"
"PYT"
"PYTH"
"PYTHO"
"PYTHON"




# s=""
# s=s+"P"
# s=s+"Y"
s=""
for i in str:
    s=s+i
    print(s)
# i="P"     s="P"
# i="Y"     s="PY"
print()
s="hello"
n=len(s)
for i in s:
    print(s[0:n])
    n=n-1

