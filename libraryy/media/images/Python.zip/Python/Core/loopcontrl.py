# #break continue and pass
# #BREAK
# s="hello"
# for i in s:
#     if(i=="l"):
#         break
#     print(i,end=" ")
# print()
# #CONTINUE
# s="hello"
# for i in s:
#     if(i=="l"):
#         continue
#     print(i,end=" ")
# #PASS
# for i in range(1,101):
#     if(i%7!=0):
#           pass #Do nothing or no opeartion
#     else:
#         print(i)

# #if(cond):
#    stmts
# elif(cond):
#    stmts
# else:
#     pass
# #def f():
#     pass    #empty function
#
# #class A:
# #     pass    #empty class
# # #if(cond):
# #     pass     #empty if block
#
# s="Python is a programming Language"
# #display the string upto a particular character
# # ch="i"
# # output:Python i
# # ch=input("Enter the character")
# # for i in s:
# #     print(i,end=" ")
# #     if(i==ch):
# #         break
# # #Check whether a number prime or not
# # primenumbers-->2,3,5,7......
#
# # 8-->1,8,2,4
# # 6-->1,6,2,3
# # 5-->1,5
# #Normal Method
# n=int(input("enter the numbers"))
# count=0
# for i in range(2,n):
#     if(n%i==0):
#         count=count+1
#         break
# if(count==0):
#     print("prime number")
# else:
#     print("Not Prime")
# #for -else
# n=int(input("Enter the number"))
# for i in range(2,n):
#     if(n%i==0):
#         print("not prime")
#         break
# else:
#     print("Prime")
# # n=4
# i=2    4%2==0   not prime
#
#
# n=5
# i=2    5%2==0  -
# i=3    5%3==0  -
# i=4    5%4==0   -
# prime
#n=[1,2..............,100]
#skip multiples of 7 and 5
for i in range(1,101):
    if(i%7==0 and i%5==0):
        continue
    print(i)

#or
for i in range(1,101):
    if(i%7!=0 or i%5!=0):

        print(i)

