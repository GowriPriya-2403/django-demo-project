# l=["john","mike","sam","Jose","Anu"]
# for i in l:
#     print('hello'+i)
# l=[1,2,3,4,5,6]
# new=[]
# for i in l:
#     new.append(i**2)
# print(new)

# n=int(input("Enter number"))
# for i in range(1,11):
#     print(n,'*',i,'=',n*i)
l=[20,13,-15,80,21,-18]
positive=[]
negative=[]
for i in l:
    if(i>0):
        positive.append(i)
    else:
        negative.append(i)
print("Positive number list",positive)
print("Count of positive numbers",len(positive))
print("Negative number list",negative)
print("Count of negative numbers",len(negative))

# n=[1,2,3,4,5,6]
# c=0
# for i in n:
#     if(i%2==0):
#         c=c+1
#         print(i)
#         if(c==2):
#             break
for i in range(1500,2701):
    if(i%7==0 and i%5==0):
        continue
    print(i)
