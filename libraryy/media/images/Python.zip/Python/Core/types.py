# x=10          # int
# y=10.7        #float
# z=5+4j        #complex
# s='Arun'      #String
# t="6"         #string
#
# l=[1,'abc',7.5]   #list
# t=(1,'banana',6.7)  #tuple
# d={'name':"meera",'age':21}   #dictionary
# u={1,3,5,(2,3),'hello'}       #set
# a=40
# b=50
# c=a<b            #boolean(True or False)
# z=None           #None Type
# print(s[3])    #n
# print(s[2:5])   #'un'
# print(l[2])      #7.5
# print(l*2)       #[1,'abc,7.5,1,'abc,7.5]
# print(d['name'])   #meera
# print(d['age'])    #21
# print(u)            #{1,3,5,(2,3),'hello'}
