# *
# * *
# * * *
# * * * *

# 1
# 2 3
# 4 5 6
# 7 8 9 10
# n=1
# for i in range(1,5):
#     for j in range(1,i+1):
#         print(n,end=" ")
#         n=n+1
#
#     print()
#
#
# # A
# # B B
# # C C C
# # D D D D
# n=65
# for i in range(1,5):
#     for j in range(1,i+1):
#         print(chr(n),end=" ")
#     n=n+1
#     print()
#
# # n=65    j=[1]       A
# # n=66    j=[1,2]     B B
# # n=67    j=[1,2,3]   C C C
# # n=68    j=[1,2,3,4] D D D D
#
# # A
# # A B
# # A B C
# # A B C D
# for i in range(1,5):
#     n=65
#     for j in range(1,i+1):
#         print(chr(n),end=" ")
#         n=n+1
#     print()
# # A
# # B C
# # D E F
# # G H I J
# n=65
# for i in range(1,5):
#     for j in range(1,i+1):
#         print(chr(n),end=" ")
#         n=n+1
#     print()
# # A
# A B
# A C D
# A E F G
# n=66
# for i in range(1,5):
#     print('A',end=" ")
#
#     for j in range(2,i+1):
#         print(chr(n),end=" ")
#         n=n+1
#     print()
#
# n=66    i=1        A
# n=66    i=2        A    B
#         j->[2]
# n=67    i=3        A   C   D
#         j->[2,3]
# n=69    i=4        A   E   F   G
#         j-->[2,3,4]
# n=4
# k=6
# for i in range(1,n+1):
#     for p in range(1,k+1):
#         print(end=" ")
#     k=k-2
#     for j in range(1,i+1):
#         print('*',end=" ")
#     print()
# n=4
# k=6
# for i in range(1,n+1):
#     for p in range(1,k+1):
#         print(end=" ")
#     k=k-2
#     for j in range(1,i+1):
#         print('*',end="   ")
#     print()

# n=4
# for i in range(1,n+1):
#     for j in range(1,i+1):
#         print('*',end=" ")
#     print()
# n=3
# for i in range(n,0,-1):
#     for j in range(1,i+1):
#         print('*',end=" ")
#     print()
# n=4
# k=6
# for i in range(1,n+1):
#     for p in range(1,k+1):
#         print(end=" ")
#     k=k-2
#     for j in range(1,i+1):
#         print('*',end=" ")
#     print()
# n=3
# k=2
# for i in range(n,0,-1):
#     for p in range(1,k+1):
#         print(end=" ")
#     k=k+2
#     for j in range(1,i+1):
#         print('*',end=" ")
#     print()

# n=4
# k=6
# for i in range(1,n+1):
#     for p in range(1,k+1):
#         print(end=" ")
#     k=k-2
#     for j in range(1,i+1):
#         print('*',end="   ")
#     print()
# n=3
# k=2
# for i in range(n,0,-1):
#     for p in range(1,k+1):
#         print(end=" ")
#     k=k+2
#     for j in range(1,i+1):
#         print('*',end="   ")
#     print()

n=4
k=6
for i in range(1,n+1):
    for p in range(1,k+1):
        print(end=" ")
    k=k-2
    for j in range(1,i+1):
        print('gglk',end="   ")
    print()
n=3
k=2
for i in range(n,0,-1):
    for p in range(1,k+1):
        print(end=" ")
    k=k+2
    for j in range(1,i+1):
        print('kkml',end="   ")
    print()