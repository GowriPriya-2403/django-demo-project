# #s=1+2+3....+10
# s=0
# i=1
# while(i<=10):
#     s=s+i
#     i=i+1
# print(s)
# #p=1*2*....*10
# p=1
# i=1
# while(i<=10):
#     p=p*i
#     i=i+1
# print(p)
# #s=1+3+5+7+9
# s=0
# i=1
# while(i<=10):
#     s=s+i
#     i=i+2
# print(s)
# #p=2*4*6*8*10
# i=2
# p=1
# while(i<=10):
#     p=p*i
#     i=i+2
# print(p)
# #s=5+10+15....+100
# i=5
# s=0
# while(i<=100):
#     s=s+i
#     i=i+5
# print(s)
# #Factorial of a number
# n=int(input("enter number"))
# f=1
# i=1
# while(i<=n):
#     f=f*i
#     i=i+1
# print("The factorial is",f)
# #Factors of a number
# n=int(input("Enter the number"))
# i=1
# while(i<=n):
#     if(n%i==0):
#         print(i)
#     i=i+1
# #Display all items in a list
# list=['banana','orange','grapes','pineapple']
# #print(l[0],l[1],l[2],l[3])
# i=0
# #l=len(list)
# while(i<len(list)):
#     print(list[i],end=" ")
#     i=i+1
# #Elements at even index position
# list=['banana','orange','grapes','pineapple']
# i=0
# while(i<len(list)):
#     print(list[i],end=" ")
#     i=i+2
#Fruitnames containing letter 'p'
list=['banana','orange','grapes','pineapple']
i=0
while(i<len(list)):
    if('p' in list[i]):
            print(list[i])
    i=i+1
#0,1,1,2,3,5,8,13,21 (Fibinocci Series)
0
1
1
2
3
5
8


