# a=int(input("Enter number1"))
# b=int(input("Enter number2"))
# c=int(input("Enter number3"))
# if(a>b and a>c):
#     print("First no is biggest")
# elif(b>a and b>c):
#     print("Second no is biggest")
# else:
#     print("Third no is boggest")

#Write a program to check the given number is 2 digit,3digit or 4 digit
# x=int(input("Enter number"))
# if(10<=x<=99):
#     print("2 digit number")
# elif(100<=x<=999):
#     print("3 digit number")
# elif(1000<=x<=9999):
#     print("4 digit number")
# else:
#     print("Th given number is either single digit or more than a 4 digit number")

#Calculator (add,sub,div,mul)
# x
# y
# op=input("Enter the operator(+ - / *)")
# if(op=='+'):

#Find the no of days in a month
# month=input("Enter the month name")
# if(month=="January" or month="march" or month="July"):
#     print("31 days")
# elif(month=="April" or month=="June")
#     print("30days")
# elif(month=="Feb"):
#     print("28 days")
# else:
#     print("Invalid")
# m=input("Enter the month name")
# d={'january':31,'February':28,'March':31,'April':30}
# if m in d:
#     print(d[m])
# else:
#     print("invalid")
# n=int(input("enter the number"))
# if(n%2==0):
#     if(n%3==0):
#         print("number is divisible by 2 and 3")
#     else:
#         print("number is divisble by 2 and not by 3")
# else:
#     if(n%3==0):
#         print("number is divisible by 3 and not by 2")
#     else:
#         print("not divisible by 2 and 3")

i=1
while(i<=10):
    print(i)
    i=i+1
    print("hello")






