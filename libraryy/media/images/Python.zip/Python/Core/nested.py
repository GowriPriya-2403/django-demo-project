for i in range(1,5):
    for j in range(1,i+1):
        print('*',end=" ")
    print()
for i in range(1,5):
    for j in range(1,i+1):
        print('#',end=" ")
    print()
for i in range(1,5):
    for j in range(1,i+1):
        print(i,end=" ")
    print()

# 1
# 1 2
# 1 2 3
# 1 2 3 4

# 1
# 4 4
# 9 9 9
# 16 16 16 16

# * * * *
# * * *
# * *
# *
for i in range(1,5):
    for j in range(1,i+1):
        print(j,end=" ")
    print()
for i in range(1,5):
    for j in range(1,i+1):
        print(i**2,end=" ")
    print()
for i in range(4,0,-1):
    for j in range(1,i+1):
        print('*',end=" ")
    print()

for i in range(1,6,2):
    for j in range(1,i+1):
        print(j,end=" ")
    print()
# 1
# 2 1
# 3 2 1
# 4 3 2 1

# 1
# 1 2
# 1 2 1
# 1 2 1 2
for i in range(0,5):
    for j in range(i+1,0,-1):
        print(j,end=" ")
    print()
for i in range(1,5):
    for j in range(1,i+1):
        if(j%2==0):
            print(2,end=" ")
        else:
            print(1,end=" ")
    print()

