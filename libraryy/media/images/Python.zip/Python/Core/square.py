from math import sqrt
#find perfect squares(1,100)

#1,4,9,16,25,36,49,64,81,100
for i in range(1,101):
    n=sqrt(i)
    s=str(n)
    x=s.split('.')
    if len(x[1])==1:
        print(i)


