# #For loop
# s="hello"
# for i in s:
#     print(i)
# n=[1,2,3,4,5,6,7,8,9,10]
# for i in n:
#     print(i)
# n=[1,2,3,4,5,6,7,8,9,10]
# for i in n:
#     if(i%2==0):
#         print(i)
# #numbers from 100-200
# for i in range(100,201):
#     print(i)
# #even numbers from 100-200
# for i in range(100,201,2):
#     print(i)
# #multiples of 5 in the range 100-200
# for i in range(100,201,5):
#     print(i)
# # #Factors of a number
# n=int(input("Enter number"))
# for i in range(1,n+1):
#     if(n%i==0):
#         print(i)
# #Factorial
# n=int(input("Enter number"))
# f=1
# for i in range(1,n+1):
#         f=f*i
# print(f)

#sum of numbers(100-200)
# s=0
# for i in range(100,201):
#     s=s+i
# print(s)
# #sum of even numbers(100,200)
# s=0
# for i in range(100,201,2):
#     s=s+i
# print(s)
# #product of numbers(100,200)
# p=1
# for i in range(100,201):
#     p=p*i
# print(p)
# Count the occurence of character in a string
# s=input("Enter the string")
# a=input("Enter the character")
# c=0
# if a in s:
#     for i in s:
#         if i==a:
#             c=c+1
#
#     print(c)
# else:
#     print("Character not present")
#Divibility by 7 and 5 in the range(1500,2700)
# for i in range(1500,2701):
#     if(i%7==0 and i%5==0):
#         print(i)
#
#Unique elements in a list
# l=[1,1,2,3,3,4,5]
# new=[]
# for i in l:
#     if i not in new:
#         new.append(i)
# print(new)
# i=1     True   new=[1]
# i=1     False  -
# i=2     True    new=[1,2]
# i=3     True    new=[1,2,3]
# i=3     False   -
# i=4     True    new=[1,2,3,4]
# i=5     True    new=[1,2,3,4,5]

#print the characters at even index position
# s="hello"
# l=len(s)#5
# for i in range(0,l):[0,1,2,3,4]
#     print(s[i])
# i=0    s[0]    h
# i=1    s[1]    e
# i=2    s[2]    l
# i=3    s[3]     l
# i=4    s[4]     o
# for i in range(0,l,2):[0,2,4]
#     print(s[i])
# i=0    s[0]    h
#
# i=2    s[2]    l
#
# i=4    s[4]     o
#sum of all elemnts in a list
# l=[10,20,30,40]
# s=0
# for i in l:
#     s=s+i
# print(s)
#Create a new list from existing 2 lists
# l1=[1,2,3,4,5,6]
# l2=[10,15,20,25]
# l3=[]
# for i in l1:
#     if(i%2!=0):
#         l3.append(i)
# print(l3)
# for i in l2:
#     if(i%2==0):
#         l3.append(i)
# print(l3)
#200-400(all even digits numbers)
#
l=['banana','orange',9.8,10,7.5,3]
l1=[]
l2=[]
l3=[]
for i in l:
    if(type(i)==int):
        l1.append(i)
    elif(type(i)==str):
        l2.append(i)
    elif(type(i)==float):
        l3.append(i)
    else:
        pass
print(l1)
print(l2)
print(l3)
# i='banana'     l2=[banana]
# i='orange'     l2=[banana,orange]
# i=9.8          l3=[9.8]
# i=10            l1=[10]
# i=7.5           l3=[9.8,7.5]
# i=5              l1=[10,5]

