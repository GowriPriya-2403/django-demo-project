#while(condition):
     #statements
#1,2...10
i=1
while(i<=10):
    print(i)
    i=i+1
#100,101,...400
i=100
while(i<=400):
    print(i)
    i=i+1
#2,4,6,8,10
#2,8,14,20,26,32,38
i=2
while(i<=38):
    print(i)
    i=i+6
#4,9,14,19,24,29,34
i=4
while(i<=34):
    print(i)
    i=i+5
#1,4,9,16,25,36,49
i=1
while(i<=7):
    print(i**2)
    i=i+1
#2,5,10,17,26(1*1+1,2*2+1,3*3+1....)
i=1
while(i<=7):
    print(i**2+1)
    i=i+1
#1,8,27,64....
i=1
while(i<=10):
    print(i**3)
    i=i+1





