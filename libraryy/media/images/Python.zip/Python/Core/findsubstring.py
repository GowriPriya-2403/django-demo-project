s="abgvggxcxdfdftfscxzcff xzghchh"
str="xz"
l=len(str)
c=0

for i in range(0,len(s)):

    if(s[i]==str[0]):
        end=i+l

        s1=s[i:end]
        if(s1==str):

            c=c+1
print(c)
