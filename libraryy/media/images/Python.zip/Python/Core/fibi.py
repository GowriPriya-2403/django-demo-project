#Fibinocci series
#0,1,1,2,3,5,8,.....
a=0
b=1
print(a)

while(b<=21):
    print(b)
    a,b=b,a+b

#200--400
#for eg:200,202,....
i=200
while(i<=400):
    n=str(i)
    if(int(n[0])%2==0 and int(n[1])%2==0 and int(n[2])%2==0):
        print(i)
    i=i+1
#or
l=[2,4,6,8,0]

i=200
while(i<=400):
    n=str(i)
    if(int(n[0]) in l and int(n[1]) in l and int(n[2]) in l):
        print(i)
    i=i+1

#Reverse of a number
n=input("Enter number")
i=len(n)-1
s=""
while(i>=0):
    s=s+n[i]
    i=i-1
print(s)





