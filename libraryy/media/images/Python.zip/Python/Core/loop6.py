# # #print list items
# # l=[1,2,3,4]
# # le=len(l)
# # i=0
# # while(i<=le-1):
# #     print(l[i])
# #     i=i+1
# #
# # #print Characters in a string
# # s="hello"
# # i=0
# # le=len(s)
# # while(i<=le-1):
# #     print(s[i])
# #     i=i+1
# #
# # l=['banana','orange','grapes','cherry']
# # i=0
# # le=len(l)
# # while(i<=le-1):
# #     print(l[i])
# #     i=i+1
# #even index position
# l=['banana','orange','grapes','cherry']
# i=0
# le=len(l)
# while(i<=le-1):
#     print(l[i])
#     i=i+2
# #1,2,4,7,11,16
# i=1
# k=1
# while(i<=16):
#     print(i)
#     i=i+k
#     k=k+1
# #0,3,8,15,24,35....100
# i=0
# k=3
# while(i<=100):
#     print(i)
#     i=i+k
#     k=k+2
#s=0+3+15+.....100
i=0
k=3
sum=0
while(i<=100):
    print(i,end=" ")
    sum=sum+i
    i=i+k
    k=k+2
print()
print(sum)







