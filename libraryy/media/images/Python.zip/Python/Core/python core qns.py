#while or for loop
#print the series
#105,98,91.................7
# for i in range(105,6,-7):
#     print(i,end=" ")

# i=105
# while(i>=7):
#     print(i)
#     i=i+1

#1,2,6,24,120,720
#2,22,222,2222,22222,222222.............upto a limit

# 'hello'*2->'hellohello'
#
# # '2'*2-->22
# '2'
# '2'*2
# '2'*3
# '2'*4
# '2'*5
# '2'*6
for i in range(1,7):
     print('2'*i)
#write a program to get the following output

# 1   49
# 2   48
# --
#
# --
# 49   1
k=49
for i in range(1,50):
     print(i," ",k)
     k=k-1