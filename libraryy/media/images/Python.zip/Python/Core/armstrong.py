#n=int(input("enter number"))   #153
# s=str(n)
# l=len(s)   #3
# sum=0
# for i in s:
#     sum+=int(i)**l
# if(sum==n):
#     print("Number is Armstrong")
# else:
#     print("Not a Armstrong Number")
#
# i='1'          sum=0+1
# i='5'          sum=0+1+125
# i='3'          sum=0+1+125+27=153
# Number is Armstrong

#Check whether a number is prime or not
# n=int(input("Enter the number"))
#
# count=0
#
# for i in range(2,n):
#     if(n%i==0):
#         count=count+1
#         break
# if(count==0):
#     print("prime no")
# else:
#     print("not a prime no")
#
# n=8      count=0
# i=2      if(8%2==0):(True)
#              count=1
# if(count==0):false
# not a prime no
#
# n=5      count=0
# i=2      5%2==0  false
# i=3      5%3==0  false
# i=4      5%4==0  false
# if(count==0): True
# Prime no

n=int(input("Enter the number"))
for i in range(2,n):
    if(n%i==0):
        print("not a prime number")
        break
else:
    print("Number is prime")
