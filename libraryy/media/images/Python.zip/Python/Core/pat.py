# s=6
# for i in range(2,9,2):
#     for k in range(2):
#         for p in range(1,s+1):
#             print(end=" ")
#         for j in range(1,i+1):
#             print('*',end=" ")
#         print()
#     s=s-2
s=6
for i in range(2,9,2):
    for k in range(2):
        for p in range(1,s+1):
            print(end=" ")

        for j in range(1,i+1):
            print('*',end=" ")
        print()
    s=s-2