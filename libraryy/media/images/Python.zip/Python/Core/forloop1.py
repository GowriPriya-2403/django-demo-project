# # colors=['red','green','blue']
# #
# # for i in colors:
# #     print(i)
#
# # s="red"
# # for i in s:
# #     print(i)
#
# # for i in (2,3,4):
# #     print("i")
#
# # for i in range(7,2,-9):
# #     print(i)
#
# # for i in range(4,10):
# #     i=i+3
# #     print(i)
#
# # for i in range(1500,2701):
# #     if(i%5==0 and i%7==0):
# #         continue
# #     print(i)
#
# # s="Python is a programming Language"
# # ch=input("Enter character")
# # for i in s:
# #     print(i,end="")
# #     if i==ch:
# #         break
# l=[23,45,26,13,14,80,28]
# l1=[]
# for i in l:
#     if(i%2==0):
#         #print(i)
#         l1.append(i)
# print(l1)
# # i=23      false    l1=[]
# # i=45      ' '       l1=[]
# # i=26       true     l1=[26]
# # i=13       false    l1=[26]
# # i=14       true     l1=[26,14]
# # --
# # -
#
# for i in range(1,4):
#     for j in range(1,4):
#         print(i,end=" ")
#     print()
#
# # 1
# # 2 2
# # 3 3 3
# n=['java','python','c++']
# for i in range(1,3):
#     for j in n:
#         print((i,j))
# i=1     j-->[java,python,c++]
# (1,java),(1,python),(1,c++)
# i=2    j-->[java,python,c++]
# (2,java),(2,python),(2,c++)
# for i in range(1,4):
#     for j in range(1,4):
#         print(i,end=" ")
#     print()
# i=1    j->[1,2,3]
#          1 1 1
# i=2      2 2 2
# i=3      3 3 3
# #

# k=1
# for i in range(1,4):
#     for j in range(1,i*2):
#         print(k,end="")
#         k=k+1
#     print()

# for i in range(1,5):
#     for j in range(1,i+1):
#         print('*',end=" ")
#     print()
# for i in range(3,0,-1):
#     for j in range(1,i+1):
#         print('*',end=" ")
#     print()
k=6
for i in range(1,5):
    for p in range(1,k+1):
        print(end=" ")
    k=k-2
    for j in range(1,i+1):
        print('*',end="   ")
    print()
k=2
for i in range(3,0,-1):
    for p in range(1,k+1):
        print(end=" ")
    k=k+2
    for j in range(1,i+1):
        print('*',end="   ")
    print()





