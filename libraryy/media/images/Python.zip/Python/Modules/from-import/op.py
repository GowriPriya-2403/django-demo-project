from area import rectangle

rectangle(7,8)