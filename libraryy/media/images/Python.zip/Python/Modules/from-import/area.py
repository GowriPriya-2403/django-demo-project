def triangle(b,h):
    print(0.5*b*h)
def rectangle(l,b):
    print(l*b)
def circle(r):
    print(3.14*r*r)
def square(a):
    print(a*a)