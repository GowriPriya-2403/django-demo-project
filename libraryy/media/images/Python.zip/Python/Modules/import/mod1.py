def msg():
    print("hello")
x=20