# # f=open("k.txt",'r+')
# # print(f.read())   #first read
# # f.write('Python')  #second write
# # f.close()
#
# f=open("k.txt",'r+')
# f.write("c")     #First write
# print(f.read())  #second read
# f.close()

# f=open("k.txt",'w+')#if file already exists w+ mode erases the file contents
# f.write("hello")
# print(f.read())
# f.close()

# f=open("k.txt",'a+')#File pointer position is at the end of the file.
# f.write("java")
# print(f.tell())
# f.seek(8,0)
# print(f.read())
# f.close()
