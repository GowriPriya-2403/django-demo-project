import os
print(os.getcwd())
#f=open("C://users/lumin/bhavya/k.txt",'r')
os.chdir("C://users/lumin/bhavya")
#print(os.getcwd())
f=open("k.txt","r")
print(f.read())