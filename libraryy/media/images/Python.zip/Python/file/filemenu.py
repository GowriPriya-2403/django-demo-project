def create_file():
    filename=input("Enter the filename")
    f=open(filename,"w")
    content=input("Enter the content")
    f.write(content)
    f.close()
def read_file():
    try:
        filename=input("enter the filename")
        f=open(filename,"r")
        print(f.read())
    except:
        print("file does not exist")
    else:
        f.close()
def append_file():
    filename=input("Enter the filename")
    f=open(filename,"a")
    content=input("Enter the content")
    f.write(content)
    f.close()
def search_file():
    filename=input("Enter the filename")
    f=open(filename,"r")
    word=input("Enter the word")
    a=f.read()
    if word in a:
        print("The word is present")
    else:
        print("The word is not found")
def delete_file():
    filename=input("enter the file")
    import os
    os.remove(filename)
    print("The file",filename,"is deleted.......")


while(1):
    print("FILE OPERATIONS")
    print("1.Create File")
    print("2.Read File")
    print("3.Append File")
    print("4.Search File")
    print("5.Delete File")
    ch=int(input("Enter your choice"))
    if ch==1:
        create_file()
    elif ch==2:
        read_file()
    elif ch==3:
        append_file()
    elif ch==4:
        search_file()
    elif ch==5:
        delete_file()
    else:
        exit()

