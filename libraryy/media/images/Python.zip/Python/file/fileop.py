
#write mode
# f=open("k.txt","w")
# f.write("hello")
# f.write("\nPython")

#read mode
#f=open("k.txt","r")
#print(f.read())
#print(f.readlines())  #List of lines in a file
# print(f.readline())
# print(f.readline())

# s=f.read(4)
# print(s)


# #Append Mode
# f=open("k.txt","a")
# f.write("Java")
# f.close()

#Write a program to find the no of uppercase,lowercase letters and spaces in a file
# f=open("k.txt","r")
# s=f.read()
# print(s)
# c1=0;c2=0;c3=0
# for i in s:
#     if(i.isupper()):
#         c1+=1
#     elif(i.islower()):
#         c2+=1
#     elif(i.isspace()):
#         c3+=1
#     else:
#         pass
# print("Uppercase",c1,"Lowercase",c2,"spaces",c3)
# #Write a program to append the contents of one text file into another file.
# f=open("p.txt","r")
# s=f.read()
# m=open("k.txt","a")
# m.write(s)
# n=open("k.txt","r")
# print(n.read())
#Write a program to find the no of lines in a file.
f=open("../bhavya/k.txt","r")
l=f.readlines()
print(len(l))

