# #FUNCTION BASED
# from threading import Thread
# from time import sleep
# def f1():
#     for i in range(1,6):
#
#         print("Python")
#         sleep(1)
# def f2():
#
#     for i in range(1,6):
#
#         print("Hi")
#         sleep(1)
# # f1()
# #
# # f2()
# t1=Thread(target=f1,args=[])# creates thraed instance(object) t1
# t2=Thread(target=f2,args=[])#craetes thread insatnce(object)t2
# t1.start() #To start thread t1 execution
# t2.start() #to start thread t2 execution
# # t1.join() #joins t1 to main thread after its execution and blocks main thread until t1 execution
# # t2.join()  #joins t2 to main thread after its execution and blocks main thread until t2 execution
#
# print("Hello")

