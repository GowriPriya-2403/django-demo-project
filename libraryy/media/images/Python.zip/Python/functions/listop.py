#Menu driven
# 1)create list
# 2)search element
# 3)print list

#import listop1
from listop1 import *
l=[]
while(True):
    print('1.Create List')
    print('2.Search List')
    print('3.print List')
    ch=int(input("Enter the choice"))
    if ch==1:
        #l=listop1.create_list()
        l=create_list()
    elif ch==2:
        #listop1.search_list(l)
        search_list(l)
    elif ch==3:
        #listop1.print_list(l)
         print_list(l)
    else:

        exit()