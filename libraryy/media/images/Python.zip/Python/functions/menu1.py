#Menu Driven Code-Arithmetic Operations
def add():
    n1=int(input("Enter number"))
    n2=int(input("Enter numnber"))
    sum=n1+n2
    return(sum)
def sub():
    n1=int(input("Enter number"))
    n2=int(input("Enter numnber"))
    Diff=n1-n2
    #print(Diff)
    return Diff
def div():
    n1=int(input("Enter number"))
    n2=int(input("Enter numnber"))
    Div=n1/n2
    #print(Div)
    return Div
def mul():
    n1=int(input("Enter number"))
    n2=int(input("Enter numnber"))
    Product=n1*n2
    #print(Product)
    return Product
print("ARITHMETIC OPERATIONS")
print('1.Add')
print('2.Subtraction')
print('3.Division')
print('4.Multiplication')

while(True):
    ch=int(input("Enter the choice"))
    if ch==1:
        s=add()
        print(s)
    elif ch==2:
        d=sub()
        print(d)
    elif ch==3:
        q=div()
        print(q)
    elif ch==4:
        p=mul()
        print(p)
    else:
        print("Invalid choice")
        exit()