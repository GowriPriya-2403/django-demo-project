# #square lambda definition
#
# # s=lambda a:a*a
# # print(s(4))
# #
# # s=lambda a,b:a+b
# # print(s(7,8))
# #MAP Function
# #Without using lambda
# n=[1,2,3,4]
# def square(x):
#     return x*x
# print(list(map(square,n)))
# print(tuple(map(square,n)))
# print(set(map(square,n)))
#
# #Using Lambda
# print(list(map(lambda x:x*x,n)))

#Filter
# n=[1,2,3,4,5,6,7,8,9,10]
# print(list(filter(lambda x:x%2==0,n)))
#
# print(list(filter(lambda x:x%2==0 and x%3==0,range(100,201))))

#Reduce

import functools
n=[1,2,3,4]
print(functools.reduce(lambda a,b:a+b,n))
print(functools.reduce(lambda a,b:a*b,n))
#Home Work
# n=[-21,4,8,-2,-10,5,16,-3,-25,81]
# #Find the sum of numbers
# #Find the sum of positive odd numbers
# #find the sum of negative even numbers
# #(Using Filter and reduce)





