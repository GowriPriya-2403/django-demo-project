# def avg():
#     count=int(input("Enter the count"))
#     s=0
#     for i in range(count):
#         n=int(input("enter number"))
#         s=s+n
#
#     #print(s/count)
#     return(s/count)
# print(avg())
#
# s=avg()
# print(s)
# count=int(input("Enter count"))
# s=0
# #avg=sum/count
# for i in range(count):
#     n=int(input("enter number"))
#     print(n)
#     s=s+n
#     print(s)
# avg=s/count
# print(avg)