def add():
    n1=int(input("Enter number"))
    n2=int(input("Enter number"))
    sum=n1+n2
    print(sum)
add()