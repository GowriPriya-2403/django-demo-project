# def fact():
#     num=int(input("Enter number"))
#     i=1
#     fact=1
#     while(i<=num):
#         fact=fact*i
#
#         i=i+1
#     print(fact)
# fact()

#Define a function to print the sum of even numbers in a list
def f():
    l=[24,67,14,25,78,12,90]
    s=0
    for i in l:
        if(i%2==0):
            s=s+i

    print(s)
f()