def count_down(start):
    print(start)
    n=start-1
    if n>0: #base condition
        count_down(start-1)


count_down(3)
