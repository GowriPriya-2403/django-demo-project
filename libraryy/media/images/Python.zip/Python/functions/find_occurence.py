def occurence(s):
    d={}
    for i in s:
        if(i!=" ") and (i not in d):
            c=s.count(i)
            d[i]=c
            print(d)

s="Hello World"
occurence(s)