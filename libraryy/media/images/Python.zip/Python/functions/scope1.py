#Global

# x=10 # global
# print(x)
# def f():
#     print(x)
# f()
# def f():
#     global x
#     x=10
#
#     print(x)
#     x=x+1
# f()
# print(x)

#non local or enclosed scope
#used in nested function
#
# def outer():
#     x=10
#     def inner():
#         x=20      #non local( it can be accessed inside the inner function only.)
#         print(x)
#     inner()
#     print(x)
#
# outer()

#nonlocal
# def outer():
#     x=10
#     print("Before calling inner function",x)
#     def inner():
#         nonlocal x
#         x=20
#         print("Inside inner function",x)
#     inner()
#     print("After calling inner function",x)
#
# outer()

#Built in scope
from math import pi

print(pi)
def k():
    print(pi)
k()
def f():
    def g():
        print(pi)
    g()
f()





