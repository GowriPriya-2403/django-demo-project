#Q).Write a function to print a greeting msg
def greeting():
    n=input("Enter name")
    print("welcome",n)
greeting()
#or
def greeting(n):

    print("welcome",n)
name=input("Enter name")
greeting(name)
# Q).Write a function to check whether a no is even or odd
def check_even():
    n=int(input("Enter no"))
    if(n%2==0):
        print("Even")
    else:
        print("Odd")
check_even()
# Q).write a function to print first 10 numbers
def firstnumber(k):
    i=0
    while(i<=k):
        print(i)
        i=i+1
n=int(input("Enter limit"))
firstnumber(n)
