def create_list():
    l=[]
    count=int(input("Enter the count"))
    for i in range(count):
        n=int(input("Enter the element"))
        l.append(n)
        #print(l)
    return l

l=create_list()

def search_list(l):
    ele=int(input("Enter the element to be searched"))
    if ele in l:
        print("Element found")
    else:
        print("Not found")
search_list(l)

def print_list(l):
    print(l)

print_list(l)