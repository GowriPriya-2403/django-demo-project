# def add():
#     "Addition of 2 numbers"
#     x=int(input("Enter number"))
#     y=int(input("Enter number"))
#     sum=x+y
#     #print(sum)
#     return sum
#
# # s=add()
# # print(s)
# print(add())
#Define a function to find Simple Interest SI=P*N*R/100.(using return statement)
# P-->Amount
# N--->no of years
# R-Rate of Interest
def simple_interest():
    p=int(input("Enter the Pricipal Amount"))
    n=int(input("Enter no of years"))
    r=float(input("Enter the rate"))
    si=p*n*r/100
    return si
s=simple_interest()
print("The SImple Interest is",s)

