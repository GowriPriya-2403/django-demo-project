# #Global
# x=10      #global(we can access the varaible x anywhere inside the program)
# print(x)
# def f():
#     print(x)
#
# f()
#local
# def f():
#     x=10      #local
#     print(x)
#
# f()
# print(x)
def f():
    global x
    x=10      #local
    print(x)
def g():
    print(x)

f()
g()
print(x)

