import sqlite3

con=sqlite3.connect('shop.db')
#
# con.execute('create table customer(cust_id int primary key,name varchar(20),number varchar(30))')
# con.execute('insert into customer values(1,"David","25355")')
# con.execute('insert into customer values(2,"John","6677")')
# con.execute('insert into customer values(3,"Robert","98755")')
# con.execute('insert into customer values(4,"Betty","45565")')
#
# con.execute('create table orders(order_id,amount,customer_id)')
# con.execute('insert into orders values(1,200,10)')
# con.execute('insert into orders values(2,500,3)')
# con.execute('insert into orders values(3,300,6)')
# con.execute('insert into orders values(4,800,5)')
# con.execute('insert into orders values(5,100,8)')
#
# con.commit()
# print("Tables created succsessfully")

#INNER JOIN
k=con.execute("""select name,customer.cust_id,amount,order_id
              from  customer inner join orderss
              on customer.cust_id=orders.customer_id""")
print(k.fetchall())
#LEFT OUTER JOIN
k=con.execute("""select name,customer.cust_id,amount,order_id
              from  customer left join orders
              on customer.cust_id=orders.customer_id""")
print(k.fetchall())
#cross join
k=con.execute("""select name,customer.cust_id,amount,order_id
              from  customer cross join orders""")
print(k.fetchall())