import sqlite3  #Built in module in python to connect with sqlite Db
con=sqlite3.connect('company.db')

# print("DATABASE CREATED")
#Sql query for creating table employee
'''sql_command="""create table employee(empid int primary key,
#                    name varchar(20),
#                    age int,
#                    place varchar(20),
#                    gender char(1),
#                    salary int)"""'''
# #con.execute(sql_command)
# # print("Table Created Successfully")
# #INSERTION
# # con.execute("insert into employee values(1,'Arun',23,'ekm','m',20000)")
# # con.execute("insert into employee values(2,'Anu',27,'tvm','f',25000)")
# # con.execute("insert into employee values(3,'Kiran',26,'ekm','m',30000)")
# # con.execute("insert into employee values(4,'Sam',23,'tcr','m',25000)")
# # con.commit()
# # print("Added Records Successfully")
#
# #Retrieval or Read
# #
# # k=con.execute("select * from employee")
# # print(k.fetchall())
# # # for i in k:
# # #     print(i)
# # k=con.execute("select * from employee")
# # for i in k:
# #     print("ID",i[0],"NAME",i[1],"AGE",i[2],"PLACE",i[3],"GENDER",i[4],"SALARY",i[5])
# #
# #
# # k=con.execute("select name,age from employee")
# # for i in k:
# #     print("Name",i[0],"age",i[1])
#
# # k=con.execute("select * from employee where age<26")
# # print(k.fetchall())
# # k=con.execute("select * from employee where name='Sam'")
# # print(k.fetchall())
# # k=con.execute("select * from employee where name!='Sam'")
# # print(k.fetchall())
# # k=con.execute("select * from employee where age in (24,26)")
# # print(k.fetchall())
# # k=con.execute("select * from employee where salary between 20000 and 27000")
# # print(k.fetchall())
# # k=con.execute("select * from employee where name like 'A%'")
# # print(k.fetchall())
# # k=con.execute("select * from employee where name like 'A__'")
# # print(k.fetchall())
# # k=con.execute("select * from employee where name like '_A_'")
# # print(k.fetchall())
# # k=con.execute("select * from employee where name like '%m'")
# # print(k.fetchall())
# # k=con.execute("select * from employee where name like '%n'")
# # print(k.fetchall())
# # k=con.execute("select * from employee where name like '_n'")
# # print(k.fetchall())
# #UPDATE OPERATION
# # print("Before updation")
# # k=con.execute('select * from employee')
# # print(k.fetchall())
# # con.execute('update employee set name="Manu",place="tcr" where empid=1')
# # con.commit()
# # print("After updation")
# # t=con.execute('select * from employee')
# # print(t.fetchall())
#Delete Operation
# print("Before Deletion")
# k=con.execute('select * from employee')
# print(k.fetchall())
# con.execute('delete from employee where empid =2')
# con.commit()
# print("After Deletion")
# t=con.execute('select * from employee')
# print(t.fetchall())
# #AND OR NOT CONDITION
# k=con.execute('select * from employee where age=26 and place="ekm"')
# print(k.fetchall())
# k=con.execute('select * from employee where age=26 or salary=25000')
# print(k.fetchall())
# k=con.execute('select * from employee where not(name="Kiran")')
# print(k.fetchall())

#ORDER BY
# k=con.execute('select * from employee')
# for i in k:
#     print(i)
# print("ORDER By")
# k=con.execute('select * from employee order by salary')#Default Ascending order
# for i in k:
#     print(i)
# k=con.execute('select * from employee order by name DESC')#Descending order
# for i in k:
#     print(i)

#Distinct
con.execute("insert into employee values(5,'Sam',23,'ekm','m',55000)")
k=con.execute('select * from employee order by name DESC')#Descending order
for i in k:
    print(i)
k=con.execute('select distinct(name) from employee order by name desc')
for i in k:
    print(i)













con.close()