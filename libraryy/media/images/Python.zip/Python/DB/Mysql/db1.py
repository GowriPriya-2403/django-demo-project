import mysql.connector
# con=mysql.connector.connect(host="localhost",user="root",password="root")

# c=con.cursor()  #Cursor Object

# c.execute('create database mydb1')
#
# print("Database created successfully")

#Table creation
con=mysql.connector.connect(host="localhost",user="root",password="root",database="mydb1")
c=con.cursor()
# c.execute("create table employee(id int primary key,name varchar(20),age int,salary int)")
# print("Table created successfully")

#Insertion
# c.execute("insert into employee values(1,'Arun',23,20000)")
# c.execute("insert into employee values(2,'Anu',25,25000)")
# c.execute("insert into employee values(3,'Kiran',26,30000)")
# c.execute("insert into employee values(4,'Sam',23,27000)")
# con.commit()
# print("Inserted data successfully")

#Read or Retrieval
c.execute("select * from employee")
print(c.fetchall())




con.close()

