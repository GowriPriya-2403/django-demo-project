#for loop
s="hello"
new=[]
for i in s:
    new.append(i)
print(new)

#list comprehension
s="hello"
new=[i for i in s]
print(new)
new=[5 for i in s]
print(new)

new=[i for i in range(1,21)]
print(new)

#condition -even
new=[i for i in range(1,21) if i%2==0]
#condition -odd
new=[i for i in range(1,21) if i%2!=0]
#squares of even numbers
new=[i**2 for i in range(1,21)]
#create a new list with elemnts in the form of i**2 where i takes values from range(1,21).
l=[49,81,100,64,25]
import math
new=[math.sqrt(n) for n in l]
print(new)
#if -else
new=['even' if i%2==0 else 'odd' for i in range(10)]
print(new)
l=['apple','orange','cherry','mango','kiwi']
#create a new list with elements contains letter 'a'
new=[i for i in l if 'a' in i]
print(new)
#create a new list with numbers less than 5 from the range (1,10).
new=[i for i in range(1,10) if i<5]
print(new)
#create a new list with reverse of each string given in the tuple.
t=('apple','banana','orange','grapes','mango')
new=[i[::-1] for i in t]
print(new)
new=[i.upper() for i in t]
print(new)
#Nested loops
team1=('john','sam','mike')
team2=('meera','anu','kiran')
new=[(x,y) for x in team1 for y in team2]
print(new)
#User defined function
l=[345,675,864,123]
output:[12,18,18,6]
def f(n):
    sum=0
    for i in str(n):
        sum=sum+int(i)
    return sum

new=[f(i) for i in l]
print(new)
#set Comprehension
word="Programming"
new={i for i in word}
print(new)
#dict comprehension
n=[1,2,3,4]
#dict=(1:1,2:4,3:9,4:16})
dict={i:i**2 for i in n}
print(dict)