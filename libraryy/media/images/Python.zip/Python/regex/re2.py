# # #MATCH FUNCTION
# # import re
# #
# # s="Pet:cat I love cats "
# # m=re.match(r'Pet:\w\w\w',s)
# # if m:
# #     print("Match Found")
# #     print(m.group())
# # else:
# #     print("No Match")
# import re
# #Find all words starting with s,p or r and ends at 'at'
# s="sat mat pat cat rat"
# l=re.findall(r'[spr]at',s)
# print(l)
#
# #Find all words starting with except s,p or r and ends at 'at'
# s="sat mat pat cat rat"
# l=re.findall(r'[^spr]at',s)
# print(l)
#
# #Find all 3,4,5 digit numbers from the given string.
# s="1234556 5664 234677 987 22 6778 344456667"
# l=re.findall(r'\b\d{3,5}\b',s)
# print(l)
#
# #Find all 3,4,5 letter words from the given string.
# s="The brown fox jumps over the lazy frog"
# l=re.findall(r'\b[A-Za-z]{3,5}',s)
# print(l)
#
# #WAP to find a word starting with 'a' followed by anything and ending in 'b'
#
# s="ahhfgjjkjkgjk ^%TVGHHJ o=dfhfhb hfdhhhhfkas"
# l=re.findall(r'a.+b',s)
# print(l)
#
# #Find words containing letter 'z'
# s="abcdz zabcd abzcd hgfhhl hjhjk"
# l=re.findall(r'[a-z]*z[a-z]*',s)
# print(l)
#
# #Extract year/month/date from a string
# url="https://www.washingtonpost.com/news/football-insider/wp/2016/09/02"
# m=re.search(r'\d{4}/\d{2}/\d{2}',url)
# print(m.group())

#Replace [, .] with :
import re
s="Python is a,Programming language."
l=re.sub(r'[, .]',":",s)
print(l)

#Replace '\n' with ""
s="""keep the blue flag
flying high
chelsea"""

l=re.sub(r'\n'," ",s)
print(l)

#Find Filenames with particular extension
s="x.html,n.py,m.jpeg,k.txt,l.py,a.jpeg"
l=re.findall(r'[a-z]+.jpeg',s)
print(l)

#check whether a string contains only uppercase,lowercase,digits and _
#^$
# s="553646576789"
# m=re.search(r'^\d+$',s)   #Only digits
# if m:
#     print("Match Found",m.group())
#
# else:
#     print("No match")
import re
s="gdfugjkjjGDGHFGHH645678_"
m=re.search(r'^\w+$',s)
if m:
    print("Match Found",m.group())

else:
    print("No match")

#Only letters ^[a-z]+$
#Only digits  ^[0-9]+$
#Only uppercase,lowercase,numbers and underscore ^\w+$

#Valid email addresses

s="""john123@gmail.com,
john__123@gmail.com,
john_@gmail.com,
john_123@gmail.com,
john_123@g.com,
john123@gmail.c"""

l=re.findall(r'\b[a-z0-9]+[-_.+]?[a-z0-9]+[@][a-z0-9]+[-_]?[a-z0-9]+[.][a-z]{2,3}\b',s)
print(l)