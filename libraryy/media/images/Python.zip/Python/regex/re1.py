import re
s="""Jose is 55 and Mike is 18
     John is 55 and Sam is 32"""

l=re.findall(r'[A-Z][a-z]+',s)
print(l)