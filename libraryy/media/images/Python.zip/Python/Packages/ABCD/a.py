def msg():
    print("Hello")