from ABCD import a,b
a.msg()
b.add(7,8)

