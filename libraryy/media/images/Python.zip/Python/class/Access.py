class Person:
    def __init__(self):   #public
        self.__name=input("Enter the name") #private
        self.age=int(input("Enter the age"))
        self._salary=int(input('Enter the salary'))#Protected
    def __display(self):   #private
        print(self.__name)
        print(self.age)
        print(self._salary)
# p=Person()
# #print(p.__name,p.age,p.salary)
# p._Person__display()   #To access Private method
# print(p._Person__name) #To access Private variable
#print(p._salary)
class Employee(Person):
    def __init__(self):
        super().__init__()
        self.id=int(input("Enter the id"))
    def displaysal(self):
        print(self._salary)
e=Employee()
e.displaysal()