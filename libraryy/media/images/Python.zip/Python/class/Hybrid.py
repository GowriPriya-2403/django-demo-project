#Hybrid Inheritance
class Company:
      def __init__(self):
          self.cname=input("Enter the name")
      def display(self):
          print(self.cname)
class Development(Company):
      def __init__(self):
          super().__init__()
          self.developername=input("Enter the name of developer")
          self.did=int(input("Enter the id of developer"))
      def display1(self):
          super().display()
          print(self.developername,self.did)
class Testing(Company):
      def __init__(self):
          self.testername=input("Enter the Testername")
          self.tid=int(input("Enter the id of tester"))
      def display2(self):
          print(self.testername,self.tid)
class Project(Development,Testing):
      def __init__(self):
          self.projectname=input("Enter the Projectname")
          self.pid=int(input("Enter The id of Project"))
          Development.__init__(self)
          Testing.__init__(self)
      def display3(self):
          print(self.projectname,self.pid)
          Development.display1(self)
          Testing.display2(self)
p=Project()
p.display3()