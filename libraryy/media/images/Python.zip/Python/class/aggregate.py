import sqlite3   #Built in module used to connect Sqlite Database

con=sqlite3.connect("new.db")
# con.execute("""create table country(country_id int primary key,
# country_name varchar(20),population int,year int);""")
# con.execute("insert into country values(1,'India',1000,2020);")
# con.execute("insert into country values(2,'Nepal',200,2020);")
# con.execute("insert into country values(3,'India',1500,2021);")
# con.execute("insert into country values(4,'Sreelanka',500,2020);")
# con.execute("insert into country values(5,'Nepal',400,2021);")
# con.execute("insert into country values(6,'India',2000,2022);")
# con.execute("insert into country values(7,'Nepal',600,2023);")
# con.commit()
# k=con.execute('select sum(population),avg(population),max(population),min(population),count(population) from country')
# print(k.fetchall())
# k=con.execute('select sum(population) from country')
#Group by -having
k=con.execute('select country_name,sum(population) from country  Group by country_name having sum(population)>1500')
print(k.fetchall())
