from math import pi
class Circle:
    def __init__(self):
        self.radius=int(input("Enter the radius"))

    def area(self):
        a=pi*(self.radius**2)
        print("AREA IS:",a)
    def peri(self):
        p=2*pi*self.radius
        print("PERIMETER IS",p)
c1=Circle()
c1.area()
c1.peri()

c2=Circle()
c2.area()
c2.peri()

