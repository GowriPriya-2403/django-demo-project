class Account:
    def __init__(self):
        print("Enter the Account Details:")
        self.acctno=int(input("Enter Account Number"))
        self.name=input("Enter The Name")
        self.bal=int(input("Enter the balance amount"))
    def showbalance(self):
        print("The balance amoount is:",self.bal)
    def withdraw(self):
        amount=int(input("Enter the amount"))
        self.bal=self.bal-amount
    def deposit(self):
        amount=int(input("Enter the amount"))
        self.bal=self.bal+amount
# x=Account()
# y=Account()
#
# x.withdraw()
# x.showbalance()
#
# y.deposit()
# y.showbalance()

# #To create a fixed no of Objects
# l=[]     #Declares an empty list
# count=int(input("Enter the number"))
# for i in range(count):
#     a=Account()
#     l.append(a)
#
# #To Print details of each object
# for i in l:
#     print(i.name,i.acctno,i.bal)
# for i in l:
#      i.showbalance()
# for i in range(len(l)):
#     print(l[i].name,l[i].acctno,l[i].bal)
#
# #To print details of particular object
# print(l[0].name,l[0].acctno,l[0].bal)
#Menu Driven code For Bank Operation
l=[]
while(1):
    print("1.Create Account")
    print("2.Withdraw Amount")
    print("3.Deposit Amount")
    print("4.Show Balance")
    print("5.Exit")
    ch=int(input("Enter the choice"))
    if ch==1:
        a=Account()
        l.append(a)
    elif ch==2:
        number=int(input("Enter the Account number"))
        for i in l:
            if i.acctno==number:
                i.withdraw()
                break
        else:
            print("Account Does not exist")
    elif ch==3:
        number=int(input("Enter the Account number"))
        for i in l:
            if i.acctno==number:
                i.deposit()
                break
        else:
            print("Account Does not exist")
    elif ch==4:
        number=int(input("Enter the Account number"))
        for i in l:
            if i.acctno==number:
                i.showbalance()
                break
        else:
            print("Account Does not exist")
    else:
        exit()