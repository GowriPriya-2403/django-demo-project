class Person:
    def __init__(self):
        print("Enter the details")
        self.name=input("Enter the name")
        self.age=int(input("Enter the age"))

p1=Person()
p2=Person()

print("Name is",p1.name,"Age is",p1.age)
print("Name is",p2.name,"Age is",p2.age)