#MULTIPLE INHERITANCE
class Hospital:

    def getdetails(self):
        self.hos_name=input("Enter the hospital name")
        self.location=input("Enter the location")
        self.phone=int(input("Enter the phone number"))

    def displaydetails(self):
        print("HOSPITAL NAME",self.hos_name,"LOCATION",self.location,"PHONE",self.phone,end=" ")

class Department:
    def getdetails1(self):
        self.dname=input("Enter the departmentname")
        self.doctorname=input("Enter the doctorname")

    def displaydetails1(self):
        print("DepartmentName",self.dname,"DOCTORNAME",self.doctorname,end=" ")

class Patient(Hospital,Department):
    def getdetails2(self):
        Hospital.__init__(self)
        Department.getdetails1(self)
        self.patientname=input("Enter the patientname")
        self.age=int(input("Enter the age"))
        self.gender=input("Enter the gender")
    def displaydetails2(self):
        Hospital.displaydetails(self)
        Department.displaydetails1(self)
        print("PATIENTNAME",self.patientname,"AGE",self.age,"GENDER",self.gender)

p=Patient()
p.getdetails2()
p.displaydetails2()



