class Book:
    def __init__(self):
        self.bid=int(input("Enter the Bookid"))
        self.title=input("Enter the title")
        self.author=input("Enter the author")
        self.price=int(input("Enter  the Price"))
    def showbook(self):
        print('BOOK TITLE',self.title,"BOOK AUTHOR",self.author,"BOOKPRICE",self.price)
    def updatebook(self):
        attr=input("Enter the attribute")
        if(attr=="title"):
            self.title=input("Enter the title")
        elif(attr=="author"):
            self.author=input("Enter the author")
        elif(attr=="price"):
            self.price=int(input("Enter the Price"))
        else:
            pass


l=[]
while(1):
    print('Library Menu Driven')
    print('1.Add Books')
    print('2.BookList')
    print('3.SearchBook')
    print('4.UpdateBook')
    print('5.DeleteBook')

    ch=int(input("Enter The Choice"))
    if ch==1:
        b=Book()
        l.append(b)
    elif ch==2:
        for i in l:
            i.showbook()
    elif ch==3:
        id=int(input("Enter the id"))
        for i in l:
            if(i.bid==id):
                i.showbook()
                break
        else:
            print("Book does not Exist")
    elif ch==4:
        id=int(input("Enter the id"))
        for i in l:
            if(i.bid==id):
                i.updatebook()
                break
        else:
            print("Book does not Exist")
    elif(ch==5):
        id=int(input("Enter the id"))
        for i in l:
            if(i.bid==id):
                l.remove(i)
                print("The Book is deleted")
                break
        else:
            print("Book does not Exist")
    else:
        exit()

