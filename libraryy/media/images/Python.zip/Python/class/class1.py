class Person:
    def __init__(self,n,a):#Constructor method to create and initialize objects attributes.
        self.name=n
        self.age=a

p1=Person('Arun',23) #Creates object p1 of Class Person.
#This statement calls __init__ function defined inside class Person automatically and initializes
#attributes.Here name and age are attributes.
p2=Person('Anu',24) #Creates object p2 of Class Person.
print(p1,p2)
print(p1.name,p1.age)#objectname.attribute
print(p2.name,p2.age)