from abc import ABC,abstractmethod

#Abstract Class
class Shape(ABC):
    def __init__(self,shapename):
        self.shape=shapename
    def show(self):
        print(self.shape)

    @abstractmethod
    def area(self):
        pass

class Triangle(Shape):
    def __init__(self):
        super().__init__("Triangle")
        self.sides=int(input("Enter the number"))
        self.breadth=int(input("Enter the braedth"))
        self.height=int(input("Enter the height"))

    def area(self):
        print(0.5*self.breadth*self.height)

class Rectangle(Shape):
    def __init__(self):
        super().__init__("Rectangle")
        self.sides=int(input("Enter the number"))
        self.width=int(input("Enter the width"))
        self.height=int(input("Enter the height"))

    def area(self):
        print(self.width*self.height)
t=Triangle()
t.show()
t.area()

r=Rectangle()
r.show()
r.area()



