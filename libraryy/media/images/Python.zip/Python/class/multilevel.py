#MULTILEVEL
#SINGLE LEVEL INHERITANCE
class Person:
    def __init__(self):
        self.name=input("Enter the name")
        self.age=int(input("Enter the age"))
    def show(self):
        print("NAME:",self.name,"AGE",self.age,end=" ")

class Employee(Person):
    def __init__(self):
        super().__init__()
        self.salary=int(input("Enter the salary"))
        self.empid=int(input("Enter the id"))
    def show1(self):
        super().show()
        print("SAlary",self.salary,"EMPID",self.empid,end="")

class Department(Employee):
    def __init__(self):
        super().__init__()
        self.dname=input("Enter the name")
        self.dhod=input("Enter the HOD")
    def show2(self):
        super().show1()
        print("DNAME",self.dname,"DHOD",self.dhod)

d=Department()

#d.show()
d.show2()