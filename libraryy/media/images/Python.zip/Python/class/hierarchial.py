#hierarchial Inheritance
class Vehicle:
    def __init__(self):
        self.name=""
        self.model=""
        self.price=""
        self.year=""
    def getspec(self):
        self.name=input("Enter name")
        self.model=input("Enter model")
        self.price=int(input("Enter price"))
        self.year=int(input("Enter the year"))
    def displayspec(self):
        print(self.model,self.price,self.year)
class Bike(Vehicle):
    def __init__(self):
        super().__init__()
        self.cc=""
    def getbikespec(self):
        self.cc=int(input("Enter the CC"))
    def displaybikespec(self):
        print(self.cc)
class Car(Vehicle):
    def __init__(self):
        super().__init__()
        self.mileage=""
    def getcarspec(self):
        self.mileage=int(input("Enter the mileage"))
    def displaycarspec(self):
        print(self.mileage)
# c=Car()
# c.getspec()
# c.getcarspec()
# c.displayspec()
# c.displaycarspec()
b=Bike()
b.getspec()
b.getbikespec()
b.displayspec()
b.displaybikespec()