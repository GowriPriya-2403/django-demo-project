# #SINGLE LEVEL INHERITANCE
# class Person:
#     def __init__(self):
#         self.name=input("Enter the name")
#         self.age=int(input("Enter the age"))
#     def show(self):
#         print("NAME:",self.name,"AGE",self.age,end=" ")
#
# class Employee(Person):
#     def __init__(self):
#         super().__init__()
#         self.salary=int(input("Enter the salary"))
#         self.empid=int(input("Enter the id"))
#     def show1(self):
#         super().show()
#         print("SAlary",self.salary,"EMPID",self.empid)
#
# e=Employee()
#
# #e.show()
# e.show1()

class Num:
    def __init__(self):
        self.n1=""
        self.n2=""
    def read_num(self):
        self.n1=int(input("Enter the number"))
        self.n2=int(input("Enter the number"))
class Sum(Num):
    def sum(self):
        s=self.n1+self.n2
        print("The sum is",s)
a=Sum()
a.read_num()
a.sum()




