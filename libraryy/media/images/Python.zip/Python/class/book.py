n#Library Management System
#Menu Driven code
class Book:
    def __init__(self):
        self.bid=int(input("Enter the id of Book"))
        self.title=input("Enter the title of book")
        self.author=input("Enter the author name")
        self.price=int(input("Enter the price"))
    def showdetails(self):
        print(self.bid,self.title,self.author,self.price)
    def updatebook(self):
        attr=input("Enter the attribute to be modified")
        if(attr=="title"):
            self.title=input("Enter the new title")
        elif(attr=="author"):
            self.author=input("Enter the new author")
        elif(attr=="price"):
            self.price=int(input("Enter the price"))

l=[]
while(1):
    print("1.Add book")
    print('2.Showdetails')
    print('3.updatebook')
    print('4.search')
    print('5.deletebook')
    print('6.exit')
    ch=int(input("Enter the choice"))
    if ch==1:
        b=Book()
        l.append(b)
    elif ch==2:
        for i in l:
            i.showdetails()
    elif ch==3:
        id=int(input("Enter the bookid"))
        for i in l:
            if(i.bid==id):
                i.updatebook()
                break
        else:
            print("Invalid Bookid")
    elif ch==4:
        id=int(input("Enter bookid"))
        for i in l:
            if(i.bid==id):
                print("The searched book is available")
                i.showdetails()
                break
        else:
            print("Invalid Bookid and Pls enter valid bookid")
    elif ch==5:
        id=int(input("Enter book id"))
        for i in l:
            if(i.bid==id):
                l.remove(i)
                print("Book with bookid",i.bid,"is deleted")
                break
        else:
            print("Invalid bookid")
    else:
        exit()




