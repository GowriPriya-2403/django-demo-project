class Book:
    def __init__(self):
        print("Enter the Book Details")
        self.title=input("Enter the BookTitle")
        self.author=input("Enter the Book Author")
        self.price=int(input("Enter the Price"))
    def show(self):
        print("TiTle:",self.title,"Author:",self.author,"Price",self.price)
    def gettitle(self):
        print("Title",self.title)
    def getauthor(self):
        print("Author",self.author)
    def getprice(self):
        print("Price",self.price)
    def settitle(self):
        self.title=input("Enter the New title")
        self.gettitle()
    def setauthor(self):
        self.author=input("Enter the New author")
    def setprice(self):
        self.price=input("Enter the New price")




b1=Book()
b1.show()
b1.gettitle()
b1.getauthor()
b1.getprice()
b1.setauthor()
b1.setprice()
b1.settitle()
b1.show()
b2=Book()
b2.show()

# print("TiTle:",b1.title,"Author:",b1.author,"Price",b1.price)
# print("TiTle:",b2.title,"Author:",b2.author,"Price",b2.price)