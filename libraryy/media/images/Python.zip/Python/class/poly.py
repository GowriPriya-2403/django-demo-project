# #POLYMORPHISM-DUCK TYPING
# class A:
#     def show(self):
#         print("I am inside Class A")
#
# class B:
#     def show(self):
#         print("I am inside Class B")
#
# a=A()
# a.show()
#
# b=B()
# b.show()
#METHOD OVERLOADING
# class A:
#     def show(self):
#         print("hi")
#     def show(self,a):
#         print(a)
#     def show(self,a,b):
#         print(a,b)
#
# obj=A()
# #obj.show()
# #obj.show(10)
# obj.show(20,40)
#Python Does not Support Overloading
#METHOD OVERRIDING
class A:
    def show(self):
        print("Inside Class A")
class B(A):
    def show(self):
        print("Inside Class B")
b=B()
b.show()
#when we call show() function using derived class object,only the show() inside the
#derived class is called.it overrides the show() function inside parent class.
#that concept is called Method Overriding.Inorder to call parent show() function we use
#super().show() inside derived class.

#Operator Overloading
print(1+2) #Addition of 2 integer objects
print('1'+'2')# Concatenation of two string objects
print([1,]+[2,])#Merging of two list objects

class A:
    def __init__(self,n):
        self.n=n

a=A(10) #Aclass Object
b=A(30) #A class object
print(a+b)    #Addition of two A class objects.Python does not support operator overloading
#in the case of userdefined objects.







