class Account:
    def __init__(self):
        self.acctnumber=int(input("Enter the number"))
        self.acctname=input("Enter the name")
        self.balance=int(input("Enter the balance"))

    def deposit(self):
        amount=int(input("Enter the amount"))
        self.balance=self.balance+amount
    def withdraw(self):
        amount=int(input("Enter the amount"))
        self.balance=self.balance-amount

    def showbalance(self):
        print("AccountNumber:",self.acctnumber,"BALANCE AMOUNT:",self.balance)
'''
a1=Account()

a2=Account()

a1.withdraw()
a1.showbalance()

a2.deposit()
a2.showbalance()
'''
l=[]
while(1):
    print("BANK OP MENU DRIVEN")
    print("1.Create Account")
    print("2.Deposit")
    print("3.Withdraw")
    print("4.ShowBalance")
    print("5.Exit")
    ch=int(input("Enter Your Choice"))

    if ch==1:
        a=Account()
        l.append(a)
    elif ch==2:
        number=int(input("Enter the Account number"))
        for i in l:
            if(i.acctnumber==number):
                i.deposit()
                break
        else:
            print("Account Does not exist")
    elif ch==3:
        number=int(input("Enter the Account number"))
        for i in l:
            if(i.acctnumber==number):
                i.withdraw()
                break
        else:
            print("Account Does not exist")
    elif ch==4:
        number=int(input("Enter the Account number"))
        for i in l:
            if(i.acctnumber==number):
                i.showbalance()
                break
        else:
            print("Account Does not exist")
    else:
        exit()




