# def f():
#     print(" inside function")
#
#
# x=f
# x()

# def outer():
#     def inner():
#         print("Inside Inner function")
#     inner()
# inner()

# def outer():
#     def inner():
#         print("Inside Inner function")
#     return inner
# x=outer()
# x()
# def add(x,y):
#     return x+y
# def calculate(func,x,y):
#     return func(x,y)
# result=calculate(add,4,5)
# print(result)
#
# def add(x,y):
#     return x+y
# def calculate(func,x,y):
#     return func
# result=calculate(add,4,5)
# print(result(4,5))
# def smart_divide(func):
#     def inner(a,b):
#         if b==0:
#             print("cannot divide")
#             return
#         return func(a,b)
#     return inner
# @smart_divide
# def divide(a,b):
#     print(a/b)
# divide(10,5)
# divide(10,0)

def smart_divide(func):
    def inner(a,b):
        if b==0:
            print("cannot divide")
            return
        return func(a,b)
    return inner

def divide(a,b):
    print(a/b)

x=smart_divide(divide)
x(10,0)





